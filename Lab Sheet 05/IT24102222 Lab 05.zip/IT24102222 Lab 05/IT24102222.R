setwd("C:\\Users\\Chavidi\\Downloads\\IT24102222 Lab 05")
Delivery_Times <- read.table("Exercise - Lab 05.txt", header=TRUE, sep=",")
names(Delivery_Times) <- "minutes"   
head(Delivery_Times)


histogram <- hist(Delivery_Times$minutes,
                  main= "Histogram for Delivery Times",
                  breaks = seq(20, 70, length=10),  
                  right = FALSE,
                  col="pink", border="black")


freq_table <- table(cut(Delivery_Times$minutes, 
                        breaks=seq(20,70,length=10), 
                        right=FALSE))
print(freq_table)


breaks <- histogram$breaks        
freq   <- histogram$counts        
cum.freq <- cumsum(freq)          


cum.freq.with0 <- c(0, cum.freq)
breaks.with0   <- breaks          


plot(breaks.with0, cum.freq.with0, type="o",
     main="Cumulative Frequency Polygon (Ogive)",
     xlab="Delivery Time (minutes)",
     ylab="Cumulative Frequency",
     col="blue", pch=16)


cbind(Class_Upper_Limit = round(breaks), 
      Frequency = c(freq, NA), 
      Cumulative_Freq = cum.freq.with0)


